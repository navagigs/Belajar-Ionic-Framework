**Note: for support questions, please use one of these channels:**

https://forum.ionicframework.com/
http://ionicworldwide.herokuapp.com/


#### Short description of the problem:


#### What behavior are you expecting?


**Steps to reproduce:**
1.
2.
3.

```
insert any relevant code between the above and below backticks
```

**Other information:** (e.g. stacktraces, related issues, suggestions how to fix, stackoverflow links, forum links, etc)


**Which branch are you on?** master or typescript


**Run `ionic info` from terminal/cmd prompt:** (paste output below)
